<h1 align="centre">LoungeMUSIC V1.0 🎵</h1>

### Telegram gruplarınızda müzik dinlemenize yarar 
#### POWERED BY [Bodrumlu](https://t.me/bodrumlubebekk)
### Destek kanalı [@Loungemusicsupport](https://t.me/loungemusicsupport)

<p align="center">
  <img src="https://telegra.ph/file/03f1c9ec4513c3a52bc22.jpg">
</p>

<h2> Özellikler 🔥 </h2>

- Küçük Resim Desteği
- Çalma Listesi Desteği
- Mevcut oynatma desteği
- Atlarken parça adlarını gösteriliyor
- Sıfır kesinti, tamamen kararlı
- Deezer, Youtube ve Saavn oynatma desteği
- Ayarlar paneli
- Düğmeleri ile kontrol
- Userbot otomatik katıl
- Kanal Müzik Çalma
- Youtube play için klavye seçimi desteği

## 🚀 Deployment

### 💜 Heroku

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/bodrumlubebek/LoungeMusic)

Get pyrogram (p)  `SESSION` from here:

[SESSION ALMAK ICIN TIKLA](https://t.me/StringSessionGenRobot)


### Grup için komutlar :
#### Gruptaki herkes için

- '/oynat < şarkı adı> ' - istediğiniz şarkıyı çalın
- `/oynat <sese cevap ver> ' - yanıtlanan dosyayı oynat
- '/dplay < şarkı adı> ' - deezer üzerinden istediğiniz şarkıyı çalın
- '/splay <şarkı adı> ' - jio saavn aracılığıyla istediğiniz şarkıyı çalın
- '/ytplay < şarkı adı>': doğrudan YouTube müzik üzerinden şarkı çalmak
- '/playlist ' - şimdi çalma listesini göster
- '/current ' - şimdi oynatmayı göster
- '/song < song name> ' - istediğiniz şarkıları hızlı bir şekilde indirin
- `/search <query> ' - youtube'daki videoları ayrıntılarla arayın
- '/deezer < şarkı adı> ' - deezer üzerinden hızlı bir şekilde istediğiniz şarkıları indirin
- '/saavn < şarkı adı> ' - saavn üzerinden hızlı bir şekilde istediğiniz şarkıları indirin
- '/video < şarkı adı> ' - istediğiniz videoları hızlı bir şekilde indirin

#### Sadece yöneticiler.
- `/player ' - açık müzik çalar ayarları paneli
- `/pause ' - şarkı çalmayı Duraklat
- `/resume ' - şarkı çalmaya devam et
- '/atla ' - bir sonraki şarkıyı çal
- '/end ' - müzik çalmayı Durdur
- `/userbotjoin ' - asistanınızı sohbetinize davet edin
- `/userbotleave ' - Asistanı sohbetinizden kaldırın
### Krediler


#### Özel Krediler
- [BODRUMLU OWNER](http://github.com/bodrumlu48): LoungeMusic Geliştirici


#### DESTEK VERENLER
- [SİRİDEV](https://t.me/sirisupport)
