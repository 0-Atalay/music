from DaisyXMusic.function.admins import admins
from DaisyXMusic.function.admins import get
from DaisyXMusic.function.admins import set

__all__ = ["set", "get", "admins"]
